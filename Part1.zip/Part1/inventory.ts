// Author: Your Name
// Assignment: PROG2005 A2 Part 1

interface InventoryItem {
    id: number;
    name: string;
    category: string;
    quantity: number;
    price: number;
    supplier: string;
    stockStatus: string;
    popular: string;
    comment?: string;
}

let items: InventoryItem[] = [];
let nextId: number = 1;

function initData(): void {
    items = [
        { id: nextId++, name: "MacBook Pro", category: "Electronics", quantity: 10, price: 1999, supplier: "Apple", stockStatus: "In Stock", popular: "Yes", comment: "Best seller" },
        { id: nextId++, name: "Office Chair", category: "Furniture", quantity: 3, price: 299, supplier: "IKEA", stockStatus: "Low Stock", popular: "No" },
        { id: nextId++, name: "Hammer", category: "Tools", quantity: 0, price: 15, supplier: "Stanley", stockStatus: "Out of Stock", popular: "No" }
    ];
    renderAllItems();
}

function renderAllItems(): void {
    const output = document.getElementById('output');
    if (!output) return;
    
    if (items.length === 0) {
        output.innerHTML = '<p>No items found.</p>';
        return;
    }
    
    let html = '<table border="1">';
    html += '<tr><th>ID</th><th>Name</th><th>Category</th><th>Qty</th><th>Price</th><th>Supplier</th><th>Stock</th><th>Popular</th><th>Comment</th></tr>';
    
    for (let item of items) {
        html += '<tr>';
        html += '<td>' + item.id + '</td>';
        html += '<td>' + item.name + '</td>';
        html += '<td>' + item.category + '</td>';
        html += '<td>' + item.quantity + '</td>';
        html += '<td>$' + item.price + '</td>';
        html += '<td>' + item.supplier + '</td>';
        html += '<td>' + item.stockStatus + '</td>';
        html += '<td>' + item.popular + '</td>';
        html += '<td>' + (item.comment || '') + '</td>';
        html += '</tr>';
    }
    html += '</table>';
    output.innerHTML = html;
}

function displayPopularItems(): void {
    const populars = items.filter(item => item.popular === 'Yes');
    const output = document.getElementById('output');
    if (!output) return;
    
    if (populars.length === 0) {
        output.innerHTML = '<p>No popular items.</p>';
        return;
    }
    
    let html = '<h3>Popular Items</h3><table border="1">';
    html += '<tr><th>Name</th><th>Category</th><th>Price</th></tr>';
    for (let item of populars) {
        html += '<tr>';
        html += '<td>' + item.name + '</td>';
        html += '<td>' + item.category + '</td>';
        html += '<td>$' + item.price + '</td>';
        html += '</tr>';
    }
    html += '</table>';
    output.innerHTML = html;
}

function addItem(): void {
    const name = (document.getElementById('name') as HTMLInputElement).value.trim();
    const category = (document.getElementById('category') as HTMLSelectElement).value;
    const quantity = parseInt((document.getElementById('quantity') as HTMLInputElement).value);
    const price = parseFloat((document.getElementById('price') as HTMLInputElement).value);
    const supplier = (document.getElementById('supplier') as HTMLInputElement).value.trim();
    const stockStatus = (document.getElementById('stockStatus') as HTMLSelectElement).value;
    const popular = (document.getElementById('popular') as HTMLSelectElement).value;
    const comment = (document.getElementById('comment') as HTMLInputElement).value;
    
    if (!name || !supplier) {
        alert('Name and Supplier are required');
        return;
    }
    if (isNaN(quantity) || quantity < 0) {
        alert('Quantity must be a valid number >= 0');
        return;
    }
    if (isNaN(price) || price < 0) {
        alert('Price must be a valid number >= 0');
        return;
    }
    
    const newItem: InventoryItem = {
        id: nextId++,
        name: name,
        category: category,
        quantity: quantity,
        price: price,
        supplier: supplier,
        stockStatus: stockStatus,
        popular: popular,
        comment: comment || undefined
    };
    
    items.push(newItem);
    renderAllItems();
    clearForm();
}

function deleteItemByName(): void {
    const name = prompt('Enter item name to delete:');
    if (!name) return;
    
    const index = items.findIndex(item => item.name.toLowerCase() === name.toLowerCase());
    if (index === -1) {
        alert('Item not found');
        return;
    }
    
    if (confirm('Are you sure you want to delete "' + items[index].name + '"?')) {
        items.splice(index, 1);
        renderAllItems();
    }
}

function updateItemByName(): void {
    const name = prompt('Enter item name to update:');
    if (!name) return;
    
    const item = items.find(i => i.name.toLowerCase() === name.toLowerCase());
    if (!item) {
        alert('Item not found');
        return;
    }
    
    const newQuantity = prompt('New quantity:', String(item.quantity));
    if (newQuantity !== null) {
        const qty = parseInt(newQuantity);
        if (!isNaN(qty) && qty >= 0) item.quantity = qty;
    }
    
    const newPrice = prompt('New price:', String(item.price));
    if (newPrice !== null) {
        const pr = parseFloat(newPrice);
        if (!isNaN(pr) && pr >= 0) item.price = pr;
    }
    
    renderAllItems();
}

function searchItems(): void {
    const keyword = (document.getElementById('searchInput') as HTMLInputElement).value.trim().toLowerCase();
    if (!keyword) {
        renderAllItems();
        return;
    }
    
    const filtered = items.filter(item => item.name.toLowerCase().includes(keyword));
    const output = document.getElementById('output');
    if (!output) return;
    
    if (filtered.length === 0) {
        output.innerHTML = '<p>No matching items.</p>';
        return;
    }
    
    let html = '<h3>Search Results</h3><table border="1">';
    html += '<tr><th>Name</th><th>Category</th><th>Qty</th><th>Price</th></tr>';
    for (let item of filtered) {
        html += '<tr>';
        html += '<td>' + item.name + '</td>';
        html += '<td>' + item.category + '</td>';
        html += '<td>' + item.quantity + '</td>';
        html += '<td>$' + item.price + '</td>';
        html += '</tr>';
    }
    html += '</table>';
    output.innerHTML = html;
}

function clearForm(): void {
    (document.getElementById('name') as HTMLInputElement).value = '';
    (document.getElementById('quantity') as HTMLInputElement).value = '';
    (document.getElementById('price') as HTMLInputElement).value = '';
    (document.getElementById('supplier') as HTMLInputElement).value = '';
    (document.getElementById('comment') as HTMLInputElement).value = '';
}

(window as any).addItem = addItem;
(window as any).deleteItemByName = deleteItemByName;
(window as any).updateItemByName = updateItemByName;
(window as any).searchItems = searchItems;
(window as any).displayPopularItems = displayPopularItems;
(window as any).showAllItems = renderAllItems;

window.onload = initData;